/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import javax.swing.JOptionPane;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class Vital {
    float resp, heart, bp, weight; 
    String time;
    VitalSign vs;
    PersonHistory p;

    public float getResp() {
        return resp;
    }

    public void setResp(float resp) {
        this.resp = resp;
    }

    public float getHeart() {
        return heart;
    }

    public void setHeart(float heart) {
        this.heart = heart;
    }
    public String agecalc(VitalSign vs) {
        String range="adult";
        return range;
    }
    public float getBp() {
        return bp;
    }

    public void setBp(float bp) {
        this.bp = bp;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public String ageCalc(VitalSign vs) {
        String range="";
        if (vs.age>=1 && vs.age<=3) 
            range="tod";
        else if(vs.age>=4 && vs.age<=5)
            range="presch";
        else if(vs.age>=6 && vs.age<=12)
            range="school";
        else if(vs.age>=13 && vs.age<=112)
            range="adult";
        else
          //  JOptionPane.showMessageDialog(null, "Wrong age value");
        return range;
        return range;
    }
    public String normalVital(VitalSign vs) {
     //   this.vs=vs;
        String normal="";
        String range=agecalc(vs);
        if(range=="tod") {
            if((resp>=20.0 && resp<=30.0) && (heart>=80.0 && heart<=130.0) && (bp>=80.0 && bp<=110.0) && (weight<=22.0 && weight>=31.0))
                normal="NORMAL";
            else
                normal="ABNORMAL";
        }
        else if(range=="presch") {
            if((resp>=20.0 && resp<=30.0) && (heart>=80.0 && heart<=120.0) && (bp>=80.0 && bp<=110.0) && (weight<=31.0 && weight>=40.0))
                normal="NORMAL";
            else
                normal="ABNORMAL";
        }
        else if(range=="school") {
            if((resp>=20.0 && resp<=30.0) && (heart>=70.0 && heart<=110.0) && (bp>=80.0 && bp<=120.0) && (weight<=41 && weight>=92))
                normal="NORMAL";
            else
                normal="ABNORMAL";
        }
        else if(range=="adult") {
            if((resp>=12.0 && resp<=20.0) && (heart>=55.0 && heart<=105.0) && (bp>=110.0 && bp<=120.0) && (weight>=110))
                normal="NORMAL";
            else
                normal="ABNORMAL";
        }
        else 
           // JOptionPane.showMessageDialog(null, "Wrong values added");
            return normal;
        return normal;
    }
    @Override
    public String toString() {
        return getTime();
    }
    
}
