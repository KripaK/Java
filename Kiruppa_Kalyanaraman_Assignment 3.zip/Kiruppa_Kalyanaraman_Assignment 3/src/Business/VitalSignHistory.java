/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class VitalSignHistory {
 private ArrayList <Vital> vitalSignList;
    
    public VitalSignHistory() {
        vitalSignList=new ArrayList<>();
    }

    public ArrayList <Vital> getVitalSignList() {
        return vitalSignList;
    }

    public void setVitalSignList(ArrayList <Vital> vitalSignList) {
        this.vitalSignList = vitalSignList;
    }
    public Vital addVitalSign() {
        Vital vitalSign = new Vital();
        this.vitalSignList.add(vitalSign);
        return vitalSign;
    }
    public void deleteVitalSign(Vital vitalSign){
        this.vitalSignList.remove(vitalSign);
    }
    public Vital searchAccount(float weight) {
        for (Vital vs: vitalSignList) {
            if(vs.getWeight()==weight) {
                return vs;
            } 
        }
        return null;
    }
}
