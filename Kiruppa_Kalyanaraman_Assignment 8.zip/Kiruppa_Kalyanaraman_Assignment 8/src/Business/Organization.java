/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public abstract class Organization {
     private String name;
    private UserAccountDirectory userAccountDirectory;
    private static int counter;
    private int organizationID;
    private WorkQueue workQueue;
    private PersonDirectory personDirectory;


     public Organization(String name){
        counter++;
        organizationID = counter;  
        this.name = name;
        workQueue = new WorkQueue();
        this.userAccountDirectory = new UserAccountDirectory();
        this.personDirectory = new PersonDirectory();

    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }
    
    public enum Type{
        Admin("Admin Organization"){},
        Customer("Customer Organization"){},
        Supplier("Supplier Assistant"){},
        SalesSpecialist("Sales Specialist") {},
        ShippingSpecialist("Shipping Specialist") {};
        
        private String value;
        private Type(String value){
            this.value = value;
        }
        public String getValue(){
            return value;
        }
    }

    public abstract ArrayList<Role> getSupportedRoles();
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public void setOrganizationID(int organizationID) {
        this.organizationID = organizationID;
    }

    public PersonDirectory getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(PersonDirectory personDirectory) {
        this.personDirectory = personDirectory;
    }

    @Override
    public String toString() {
        return name;
    }
    

}
