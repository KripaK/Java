/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import Business.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class OrganizationDirectory {
     private ArrayList<Organization> organizationList;
    public OrganizationDirectory(){
        organizationList = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }

    public void setOrganizationList(ArrayList<Organization> organizationList) {
        this.organizationList = organizationList;
    }
    
    public Organization createOrganization(Type type){
        
        Organization organization = null;
        if(type.getValue().equals((Type.Customer.getValue()))){
            organization = new CustomerOrganization();
            organizationList.add(organization);
    }
     if(type.getValue().equals((Type.Supplier.getValue()))){
            organization = new SupplierOrganization();
            organizationList.add(organization);
    }
     if(type.getValue().equals((Type.SalesSpecialist.getValue()))) {
         organization = new SalesOrganization();
         organizationList.add(organization);
     }
     if(type.getValue().equals((Type.ShippingSpecialist.getValue()))) {
         organization = new ShippingOrganization();
         organizationList.add(organization);
     }
     return organization;
    }

}
