/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class Order {
    private ArrayList<OrderItem> orderItemList;
    private static int count=0;
    private int orderId;
    public Order() {
        orderItemList=new ArrayList<OrderItem>();
        count++;
        orderId=count;
    }

    public ArrayList<OrderItem> getOrderItemList() {
        return orderItemList;
    }

    public void setOrderItemList(ArrayList<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }
    public OrderItem addOrder() {
        OrderItem order = new OrderItem();
        orderItemList.add(order);
        return order;
    }
    public void deleteOrder(OrderItem order){
        this.orderItemList.remove(order);
    }
      
}
