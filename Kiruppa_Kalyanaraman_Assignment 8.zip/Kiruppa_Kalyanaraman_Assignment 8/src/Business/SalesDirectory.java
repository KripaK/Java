/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class SalesDirectory {
    private ArrayList<SalesSpecialist> salesDict;
    
    public SalesDirectory() {
        salesDict = new ArrayList<SalesSpecialist>();
    }

    public ArrayList<SalesSpecialist> getSupplierDict() {
        return salesDict;
    }
    
    public SalesSpecialist addSales() {
        SalesSpecialist s = new SalesSpecialist();
        salesDict.add(s);
        return s;
    }
    
    public void removeSales(SalesSpecialist s) {
        salesDict.remove(s);
    }
}
