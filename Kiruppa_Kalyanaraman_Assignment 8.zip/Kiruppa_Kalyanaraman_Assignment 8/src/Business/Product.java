/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.Comparator;

/**
 *
 * @author Rushabh
 */
public class Product {
    private static int count = 0;
    private String prodName;
    private int price;
    private int modelNumber;
    private int availability;
    private int sold;

    public int getSold() {
        return sold;
    }

    public void setSold() {
        sold=availability;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public Product() {
        count++;
        modelNumber = count;
    }
    
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getModelNumber() {
        return modelNumber;
    }
    
    @Override
    public String toString() {
        return prodName;
    }
   public static Comparator<Product> availComparator = new Comparator<Product>() {

        public int compare(Product t, Product t1) {
           // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            int avail1=t.getAvailability();
            int avail2=t1.getAvailability();
            return avail1-avail2;
        }
       
   };
   public static Comparator<Product> quantComparator = new Comparator<Product>() {

        public int compare(Product t, Product t1) {
     //       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            int quant1=(t.getAvailability()-t.getSold())*t.price;
            int quant2=(t1.getAvailability()-t1.getSold())*t1.price;
            return quant1-quant2;
        }
       
   };
}
