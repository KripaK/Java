/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import UserInterface.ShippingSpecialistRole.ShippingSpecialistWorkArea;
import javax.swing.JPanel;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class ShippingSpecialistRole extends Role{
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount, Organization organization, Business business){
    
        return new ShippingSpecialistWorkArea(userProcessContainer, (ShippingOrganization) organization, userAccount);
      //  return null;
    }
    @Override
    public String toString() {
        return Role.RoleType.ShippingSpecialist.getValue();
    }
}
