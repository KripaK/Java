/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import UserInterface.SalesSpecialistRole.SalesSpecialistWorkArea;
import javax.swing.JPanel;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class SalesSpecialistRole extends Role{
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount, Organization organization, Business business){
    
        return new SalesSpecialistWorkArea(userProcessContainer, (SalesOrganization) organization,  userAccount, (Order) business.getOrder(), business);
   //     return null;
    }
    @Override
    public String toString() {
        return Role.RoleType.SalesSpecialist.getValue();
    }
}
