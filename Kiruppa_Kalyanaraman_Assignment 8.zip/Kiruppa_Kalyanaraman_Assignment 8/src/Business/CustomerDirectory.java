/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class CustomerDirectory extends UserAccountDirectory{
    private ArrayList<Customer> customerDict;
    
    public CustomerDirectory() {
        customerDict = new ArrayList<Customer>();
    }

    public ArrayList<Customer> getCustomerDict() {
        return customerDict;
    }

    public void setCustomerDict(ArrayList<Customer> customerDict) {
        this.customerDict = customerDict;
    }
    public Customer addCustomer() {
        Customer c = new Customer();
        customerDict.add(c);
        return c;
    }
    
    public void removeCustomer(Customer c) {
        customerDict.remove(c);
    }
    public Customer searchCustomer(String keyWord) {
        for(Customer c : customerDict) {
            if(keyWord.equals(c.getFirstName())) {
                return c;
            }
        }
        return null;
    }
}
