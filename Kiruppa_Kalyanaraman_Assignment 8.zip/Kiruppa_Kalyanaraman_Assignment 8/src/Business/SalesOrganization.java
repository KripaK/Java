/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class SalesOrganization extends Organization{
     public SalesOrganization(){
        super(Type.SalesSpecialist.getValue());
    }
    
     @Override
    public ArrayList<Role>getSupportedRoles() {
        ArrayList<Role> roles = new ArrayList<Role>();
        roles.add(new SalesSpecialistRole());
        return roles;
      
    }
}
