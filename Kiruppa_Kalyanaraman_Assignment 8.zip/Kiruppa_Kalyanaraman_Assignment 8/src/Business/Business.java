/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class Business {
    private SupplierDirectory supplier;
    private MasterOrderCatalog moc;
    private CustomerDirectory customerDirectory;
    private UserAccountDirectory userAccountDirectory;
     private OrganizationDirectory organizationDirectory;
     private Order order;
     private static Business business;
     private OrderItem orderItem;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public OrderItem getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(OrderItem orderItem) {
        this.orderItem = orderItem;
    }
    public static Business getInstance() {
        if(business == null) {
            business = new Business();
        }
        return business;
    }

    public static Business getBusiness() {
        return business;
    }

    public static void setBusiness(Business business) {
        Business.business = business;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }
    private Business() {
        supplier=new SupplierDirectory();
        moc=new MasterOrderCatalog();
        customerDirectory=new CustomerDirectory();
        this.userAccountDirectory= new UserAccountDirectory();
        organizationDirectory = new OrganizationDirectory();
        orderItem = new OrderItem();
        order = new Order();
    }

    public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(CustomerDirectory customerDirectory) {
        this.customerDirectory = customerDirectory;
    }

    public SupplierDirectory getSupplier() {
        return supplier;
    }

    public void setSupplier(SupplierDirectory supplier) {
        this.supplier = supplier;
    }

    public MasterOrderCatalog getMoc() {
        return moc;
    }

    public void setMoc(MasterOrderCatalog moc) {
        this.moc = moc;
    }
     
     public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }   
    

}
