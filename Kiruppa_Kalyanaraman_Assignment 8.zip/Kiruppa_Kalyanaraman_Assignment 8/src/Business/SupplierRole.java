/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import UserInterface.SupplierRole.SupplierWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class SupplierRole extends Role{
    String supplyName;
    ProductCatalog productCatalog;

    public String getSupplyName() {
        return supplyName;
    }

    public void setSupplyName(String supplyName) {
        this.supplyName = supplyName;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount, Organization organization, Business business){
    
        return new SupplierWorkAreaJPanel(userProcessContainer, userAccount, organization, business);
    //    return null;
    }
    @Override
    public String toString() {
        return Role.RoleType.Supplier.getValue();
    }
    public SupplierRole() {
        productCatalog = new ProductCatalog();
    }

}
