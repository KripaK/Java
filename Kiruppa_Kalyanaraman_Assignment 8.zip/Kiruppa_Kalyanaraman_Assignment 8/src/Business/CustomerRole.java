/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import UserInterface.CustomerRole.CustomerWorkAreaJPanel;
import UserInterface.SupplierRole.SupplierWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Kripa Kalyanaraman
 */
public class CustomerRole extends Role{
    
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount, Organization organization, Business business){
    
//Supplier supplier = (Supplier) userAccount.getPerson();
        return new CustomerWorkAreaJPanel(userProcessContainer, userAccount, organization, business);
    }
    @Override
    public String toString() {
        return Role.RoleType.Customer.getValue();
    }

}
